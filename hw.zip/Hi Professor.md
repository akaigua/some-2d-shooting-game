**Hi Professor,**

If you can see this file, I have to apologize for that my works about the card cannot work now. I am still working on this. I am really not proficient to object-oriented programming in python, so please forgive me for some codes in my work that seemed awkward to you.

**Best wishes,**

**Jerry Chen**